<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Accounts_model extends CI_Model {

    function get_members() {
        $query = $this->db->get('users');
        return $query->result_array();
    }
}
<?php

class Edit_accounts_model extends CI_Model{

	function display_records(){
		$query=$this->db->query("select * from crud");
		return $query->result();
	}
	function displayrecordsById($id){
		$query=$this->db->query("select * from form where id='".$u_id.”’”);
		return $query->result();
	}
	//Update
	function update_records($f_name,$l_name,$email,$username,$password,$u_id){
		$query=$this->db->query("update form SET f_name='$f_name',l_name='$lname',email='$email', username='$username', password='$password' where id='$id’");
	}	
//public function upddata($data) {
//    extract($data);
///    $this->db->where('u_id', $u_id);
 //   $this->db->update($users, array('fname' => $fname));
 ///   $this->db->update($users, array('lname' => $lname));
 //   $this->db->update($users, array('email' => $email));
 //   $this->db->update($users, array('username' => $username));
 //   $this->db->update($users, array('password' => $password));
 ///   return true;

}
}

?>

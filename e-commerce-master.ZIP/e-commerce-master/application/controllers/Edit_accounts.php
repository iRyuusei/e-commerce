<?php
class Edit_accounts extends CI_Controller{

  public function __construct(){
    //call CodeIgniter's default Constructor
    parent::__construct();
      //load database libray manually
    $this->load->database();
    //load Model
    $this->load->model('Edit_accounts_model');
  }
  public function dispdata(){
    $result['data']=$this->Edit_accounts_model->display_records();
    $this->load->view('display_records',$result);
  }
  public function updatedata(){
    $id=$this->input->get('u_id');
    $result['data']=$this->Edit_accounts_model->displayrecordsById($id);
    $this->load->view('accounts',$result);  
    if($this->input->post('update')){
      $fname=$this->input->post('fname');
      $lname=$this->input->post('lname');
      $username=$this->input->post('username');
      $password=$this->input->post('password');
      $email=$this->input->post('email');
      $this->Edit_accounts_model->update_records($f_name,$lname,$email, $username,$password,$u_id);
      echo "Date updated successfully !";
    }

  function accounts(){
        $array_items = array('username', 'email','u_id','dis_name', 'password');
        $this->load->view('accounts');



}
?>
